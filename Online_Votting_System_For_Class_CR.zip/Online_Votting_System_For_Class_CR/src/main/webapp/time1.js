function displayMessage() {
    setTimeout(function() {
        //alert("Your message after 5 seconds!");
        window.location.href = 'login.html'; // Use a relative or absolute path
     
    }, 5000);
}